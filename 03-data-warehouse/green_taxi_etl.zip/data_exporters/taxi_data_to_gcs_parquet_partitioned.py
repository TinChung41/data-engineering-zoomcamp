import pyarrow as pa
import pyarrow.parquet as pq
import os

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] ='/home/src/gcp.json'
project_id  = "de-zoomcamp-413005"
bucket_name = 'mage-demo-tt'
table_name  = 'green_data'
root_path=f"{bucket_name}/{table_name}"

@data_exporter
def export_data(data, *args, **kwargs):
    #create new date column that will be partitioned on
    #data['lpep_pickup_date'] = data['tpep_pickup_datetime'].dt.date

    #convert data to a parquet dataset table from pandas
    table = pa.Table.from_pandas(data)
    #create a GCS file system object
    gcs = pa.fs.GcsFileSystem()

    pq.write_to_dataset(
        table,
        root_path=root_path,
        partition_cols=['lpep_pickup_date'],
        filesystem=gcs
    )
